/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalmanagement;

/**
 *
 * @author Admin
 */
class Doctor {
    String name;
    double fee;

    Doctor(String name, double fee) {
        this.name = name;
        this.fee = fee;
    }

    @Override
    public String toString() {
        return name; 
    }
}
